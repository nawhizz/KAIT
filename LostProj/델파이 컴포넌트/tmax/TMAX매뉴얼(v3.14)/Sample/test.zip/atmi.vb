Option Strict Off
Option Explicit On 

Imports System
Imports System.Runtime.InteropServices
Imports System.Text

Module atmi
	'/* -------------------------- atmi.h ------------------------- */
	'/*                                                             */
	'/*              Copyright (c) 2000 Tmax Soft Co., Ltd          */
	'/*                   All Rights Reserved                       */
	'/*                                                             */
	'/* ----------------------------------------------------------- */
	
	'/* Flags to tpinit() for Tuxedo compatability */
	Const TPU_MASK As Short = &H7s 'unsolicited notification mask
	Const TPU_SIG As Short = &H1s 'signal based notification
	Const TPU_DIP As Short = &H2s 'dip-in based notification
	Const TPU_IGN As Short = &H4s 'ignore unsolicited messages
	Const TPSA_FASTPATH As Short = &H8s
	Const TPSA_PROTECTED As Short = &H10s
	
	'/* ---------- flags from API ----- */
	'/* Most Significant Two Bytes are reserved for internal use */
	Public Const TPNOFLAGS As Short = &H0s
	Public Const TPNOBLOCK As Short = &H1s
	Public Const TPSIGRSTRT As Short = &H2s
	Public Const TPNOREPLY As Short = &H4s
	Public Const TPNOTRAN As Short = &H8s
	Public Const TPTRAN As Short = &H10s
	Public Const TPNOTIME As Short = &H20s
	Public Const TPNOGETANY As Short = &H40s
	Public Const TPGETANY As Short = &H80s
	Public Const TPNOCHANGE As Short = &H100s
	Public Const TPBLOCK As Short = &H200s
	Public Const TPFLOWCONTROL As Short = &H400s
	Public Const TPSENDONLY As Short = &H800s
	Public Const TPRECVONLY As Short = &H1000s
	Public Const TPUDP As Short = &H2000s
	Public Const TPRQS As Short = &H4000s
	Public Const TPFUNC As Short = &H8000s
	
	'/* --- flags used in tpstart() --- */
    Public Const TPUNSOL_MASK As Short = &H7S
    Public Const TPUNSOL_HND As Short = &H1S
    Public Const TPUNSOL_IGN As Short = &H2S
    Public Const TPUNSOL_POLL As Short = &H4S
    Public Const TPUNIQUE As Short = &H10S
    Public Const TPONLYONE As Short = &H20S
	
	'/* Flags to tpreturn() */
    Public Const TPFAIL As Short = &H1S
    Public Const TPSUCCESS As Short = &H2S
    Public Const TPEXIT As Short = &H4S
    Public Const TPDOWN As Short = &H8S
	
	'/* ------ flags for reply type check ----- */
	Const TPREQ As Short = 0
	Const TPERR As Short = -1
	
	'/* -------- for Tuxedo Compatability ------- */
	'/* Flags to tpscmt() - Valid TP_COMMIT_CONTROL characteristic values */
	Const TP_CMT_LOGGED As Short = &H1s '/* return after commit decision is logged */
	Const TP_CMT_COMPLETE As Short = &H2s '/* return after commit has completed */
	
	'/* Return values to tpchkauth() */
	Const TPNOAUTH As Short = 0 '/* no authentication */
	Const TPSYSAUTH As Short = 1 '/* system authentication */
	Const TPAPPAUTH As Short = 2 '/* system and application authentication */
	
	'/* unsolicited msg type */
	Public Const TPPOST_MSG As Short = 1
	Public Const TPBROADCAST_MSG As Short = 2
	Public Const TPNOTIFY As Short = 3
	Public Const TPSENDTOCLI As Short = 4
	
	Const XATMI_SERVICE_NAME_LENGTH As Short = 16 '/* where x must be > 15 */
	
	Structure tpsvcinfo
		<VBFixedString(XATMI_SERVICE_NAME_LENGTH),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=XATMI_SERVICE_NAME_LENGTH)> Dim name As String
		Dim data As Integer
		Dim len_Renamed As Integer
		Dim flags As Integer
		Dim cd As Integer
	End Structure
	
	Declare Function gettperrno Lib "TMAX4GL.DLL" () As Integer
	Declare Function gettpurcode Lib "TMAX4GL.DLL" () As Integer
	
	Const TPEBADDESC As Short = 2
	Const TPEBLOCK As Short = 3
	Const TPEINVAL As Short = 4
	Const TPELIMIT As Short = 5
	Const TPENOENT As Short = 6
	Const TPEOS As Short = 7
	Const TPESVCERR As Short = 10
	Const TPESVCFAIL As Short = 11
	Const TPESYSTEM As Short = 12
	Const TPETIME As Short = 13
	Const TPETRAN As Short = 14
	Const TPGOTSIG As Short = 15
	Const TPEITYPE As Short = 17
	Const TPEOTYPE As Short = 18
	Const TPEEVENT As Short = 22
	Const TPEMATCH As Short = 23
	Const TPENOREADY As Short = 24
	Const TPESECURITY As Short = 25
	Const TPEQFULL As Short = 26
	Const TPEQPURGE As Short = 27
	Const TPECLOSE As Short = 28
	Const TPESVRDOWN As Short = 29
	Const TPEPRESVC As Short = 30
	Const TPEMAXNO As Short = 31
	
	Const TPUNSOLERR As Integer = -1
	
	'/* ---- flags used in conv[]: don't use dummy flags ----*/
	Public Const TPEV_DISCONIMM As Short = &H1s
	Public Const TPEV_SVCERR As Short = &H2s
	Public Const TPEV_SVCFAIL As Short = &H4s
	Public Const TPEV_SVCSUCC As Short = &H8s
	Public Const TPEV_SENDONLY As Short = &H20s
	Const TPCONV_DUMMY1 As Short = &H800s '/* don't use this flag: TPSENDONLY */
	Const TPCONV_DUMMY2 As Short = &H1000s '/* don't use this flag: TPRECVONLY */
	Const TPCONV_OUT As Integer = &H10000
	Const TPCONV_IN As Integer = &H20000
	
	Const X_OCTET As String = "X_OCTET"
	Const X_C_TYPE As String = "X_C_TYPE"
	Const X_COMMON As String = "X_COMMON"
	
	Const TMTYPEFAIL As Short = -1
	Const TMTYPESUCC As Short = 0
	
	Const MAXTIDENT As Short = XATMI_SERVICE_NAME_LENGTH '/* max len of identifier */
	
	Const MAX_PASSWD_LENGTH As Short = 16
	Const MAX_MNAME_LENGTH As Short = 16
	
	Const MAXTIDENTPLUS2 As Integer = MAXTIDENT + 2
	Const MAX_PASSWD_LENGTHPLUS2 As Integer = MAXTIDENT + 2
	
	Structure tpstart_t
		<VBFixedString(MAXTIDENTPLUS2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=MAXTIDENTPLUS2)> Dim usrname As String
		<VBFixedString(MAXTIDENTPLUS2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=MAXTIDENTPLUS2)> Dim cltname As String
		<VBFixedString(MAX_PASSWD_LENGTHPLUS2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=MAX_PASSWD_LENGTHPLUS2)> Dim dompwd As String
		<VBFixedString(MAX_PASSWD_LENGTHPLUS2),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=MAX_PASSWD_LENGTHPLUS2)> Dim usrpwd As String
		Dim flags As Integer
	End Structure
	
	Public Const TMQNAMELEN As Short = 15
	Public Const TMQNAMELENPLUS1 As Integer = TMQNAMELEN + 1
	Public Const TMMSGIDLEN As Short = 32
	Public Const TMCORRIDLEN As Short = 32
	
	Structure clientid_t
		Dim clientdata() As Integer
		
		'UPGRADE_TODO: �ش� ����ü�� �ν��Ͻ��� �ʱ�ȭ�Ϸ��� "Initialize"�� ȣ���ؾ� �մϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1026.htm ����Ʈ�� �����Ͻʽÿ�.
		Public Sub Initialize()
			ReDim clientdata(4)
		End Sub
	End Structure
	
	Structure tpqctl_t
		Dim flags As Integer
		Dim deq_time As Integer
		Dim priority As Integer
		Dim diagnostic As Integer
		<VBFixedString(TMMSGIDLEN),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=TMMSGIDLEN)> Dim msgid As String
		<VBFixedString(TMCORRIDLEN),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=TMCORRIDLEN)> Dim corrid As String
		<VBFixedString(TMQNAMELENPLUS1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=TMQNAMELENPLUS1)> Dim replyqueue As String
		<VBFixedString(TMQNAMELENPLUS1),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=TMQNAMELENPLUS1)> Dim failurequeue As String
		Dim cltid As clientid_t
		Dim urcode As Integer
		Dim appkey As Integer
		
		'UPGRADE_TODO: �ش� ����ü�� �ν��Ͻ��� �ʱ�ȭ�Ϸ��� "Initialize"�� ȣ���ؾ� �մϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1026.htm ����Ʈ�� �����Ͻʽÿ�.
		Public Sub Initialize()
			cltid.Initialize()
		End Sub
	End Structure
	
	Structure tpevctl_t
		Dim flags As Integer
		<VBFixedString(XATMI_SERVICE_NAME_LENGTH),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=XATMI_SERVICE_NAME_LENGTH)> Dim name1 As String
		<VBFixedString(XATMI_SERVICE_NAME_LENGTH),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr,SizeConst:=XATMI_SERVICE_NAME_LENGTH)> Dim name2 As String
		Dim qctl As tpqctl_t
		
		'UPGRADE_TODO: �ش� ����ü�� �ν��Ͻ��� �ʱ�ȭ�Ϸ��� "Initialize"�� ȣ���ؾ� �մϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1026.htm ����Ʈ�� �����Ͻʽÿ�.
		Public Sub Initialize()
			qctl.Initialize()
		End Sub
	End Structure
	
	
	'/* ----- client API ----- */
	Declare Function tpstart Lib "TMAX4GL.DLL" (ByVal ptpinfo As Integer) As Integer
	Declare Function tpend Lib "TMAX4GL.DLL" () As Integer
	Declare Function tpalloc Lib "TMAX4GL.DLL" (ByVal buftype As String, ByVal subtype As String, ByVal bufsize As Integer) As Integer
	Declare Function tprealloc Lib "TMAX4GL.DLL" (ByVal pbuffer As Integer, ByVal bufsize As Integer) As Integer
	Declare Function tptypes Lib "TMAX4GL.DLL" (ByVal pbuffer As Integer, ByRef buftype As String, ByRef subtype As String) As Integer
	Declare Sub tpfree Lib "TMAX4GL.DLL" (ByVal pbuffer As Integer)
	Declare Function tpcall Lib "TMAX4GL.DLL" (ByVal svcname As String, ByVal psendbuf As Integer, ByVal sendlen As Integer, ByRef pprecvbuf As Integer, ByRef precvlen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpacall Lib "TMAX4GL.DLL" (ByVal svcname As String, ByVal psendbuf As Integer, ByVal sendlen As Integer, ByVal flags As Integer) As Integer
	Declare Function vb_tpgetrply Lib "TMAX4GL.DLL" (ByVal cd As Integer, ByRef pprecvbuf As Integer, ByRef precvlen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpcancel Lib "TMAX4GL.DLL" (ByVal cd As Integer) As Integer
	Declare Function tmaxreadenv Lib "TMAX4GL.DLL" (ByVal envfile As String, ByVal label As String) As Integer
	
	'/* ----- unsolicited messaging API ----- */
	'UPGRADE_WARNING: tpevctl_t ����ü���� �� Declare ���� �μ��� ������ ������ Ư���� �־�� �մϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1050.htm ����Ʈ�� �����Ͻʽÿ�.
	Declare Function tpsubscribe Lib "TMAX4GL.DLL" (ByVal eventexpr As String, ByVal filter_Renamed As String, ByRef pctl As tpevctl_t, ByVal flags As Integer) As Integer
	Declare Function tpunsubscribe Lib "TMAX4GL.DLL" (ByVal sd As Integer, ByVal flags As Integer) As Integer
	Declare Function tppost Lib "TMAX4GL.DLL" (ByVal eventname As String, ByVal pbuffer As Integer, ByVal buflen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpbroadcast Lib "TMAX4GL.DLL" (ByVal lnid As String, ByVal usrname As String, ByVal cltname As String, ByVal pbuffer As Integer, ByVal buflen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpsetunsol Lib "TMAX4GL.DLL" (ByVal pfunc As Integer) As Integer
	Declare Function tpsetunsol_flag Lib "TMAX4GL.DLL" (ByVal flag As Integer) As Integer
	Declare Function tpgetunsol Lib "TMAX4GL.DLL" (ByVal unsoltype As Integer, ByRef ppbuffer As Integer, ByRef precvlen As Integer, ByVal flags As Integer) As Integer
	
	'/* ----- conversational API ----- */
	Declare Function tpsend Lib "TMAX4GL.DLL" (ByVal cd As Integer, ByVal pbuffer As Integer, ByVal buflen As Integer, ByVal flags As Integer, ByRef prevent As Integer) As Integer
	Declare Function tprecv Lib "TMAX4GL.DLL" (ByVal cd As Integer, ByRef ppbuffer As Integer, ByRef pbuflen As Integer, ByVal flags As Integer, ByRef prevent As Integer) As Integer
	Declare Function tpconnect Lib "TMAX4GL.DLL" (ByVal svcname As String, ByVal pbuffer As Integer, ByVal buflen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpdiscon Lib "TMAX4GL.DLL" (ByVal cd As Integer) As Integer
	
	'/* ----- transaction API ----- */
	Declare Function tx_begin Lib "TMAX4GL.DLL" () As Integer
	Declare Function tx_commit Lib "TMAX4GL.DLL" () As Integer
	Declare Function tx_rollback Lib "TMAX4GL.DLL" () As Integer
	Declare Function tx_set_transaction_timeout Lib "TMAX4GL.DLL" (ByVal timeout As Integer) As Integer
	
	'/* reliable queue */
	Declare Function tpenq Lib "TMAX4GL.DLL" (ByVal qname As String, ByVal svcname As String, ByVal pbuffer As Integer, ByVal buflen As Integer, ByVal flags As Integer) As Integer
	Declare Function tpdeq Lib "TMAX4GL.DLL" (ByVal qname As String, ByVal svcname As String, ByRef ppbuffer As Integer, ByRef pbuflen As Integer, ByVal flags As Integer) As Integer
	Declare Function tp_sleep Lib "TMAX4GL.DLL" (ByVal interval As Integer) As Object
	
	'/* ----- etc API ------------- */
	Declare Function tpstrerror Lib "TMAX4GL.DLL" (ByVal tperrno As Integer) As Integer
	
	' /* ----- Useful buffer manipulation function ----- */
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function vb_getstr Lib "TMAX4GL.DLL" (ByVal Fbfr As Integer, ByRef uloc As String) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function vb_getcar Lib "TMAX4GL.DLL" (ByVal Fbfr As Integer, ByRef uloc As String, ByVal dlen As Integer) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function vb_putcar Lib "TMAX4GL.DLL" (ByVal Fbfr As Integer, ByRef uloc As String, ByVal dlen As Integer) As Integer
End Module