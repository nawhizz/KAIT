Option Strict Off
Option Explicit On
Module fdl
	'/* ----------------------- usrinc/fbuf.h --------------------- */
	'/*                                                             */
	'/*              Copyright (c) 2000 Tmax Soft Co., Ltd          */
	'/*                   All Rights Reserved                       */
	'/*                                                             */
	'/* ----------------------------------------------------------- */
	
	Const SDL_CHAR As Short = 1
	Const SDL_SHORT As Short = 2
	Const SDL_INT As Short = 3
	Const SDL_LONG As Short = 4
	Const SDL_FLOAT As Short = 5
	Const SDL_DOUBLE As Short = 6
	Const SDL_STRING As Short = 7
	Const SDL_CARRAY As Short = 8
	
	'/* field types */
	Const FB_CHAR As Short = SDL_CHAR
	Const FB_SHORT As Short = SDL_SHORT
	Const FB_INT As Short = SDL_INT
	Const FB_LONG As Short = SDL_LONG
	Const FB_FLOAT As Short = SDL_FLOAT
	Const FB_DOUBLE As Short = SDL_DOUBLE
	Const FB_STRING As Short = SDL_STRING
	Const FB_CARRAY As Short = SDL_CARRAY
	
	Const BADFLDKEY As Short = 0
	Const FIRSTFLDKEY As Short = 0
	
	'/* ----- fb op mode ----- */
	Const FBMOVE_MODE As Short = 1
	Const FBCOPY_MODE As Short = 2
	Const FBCOMP_MODE As Short = 3
	Const FBCONCAT_MODE As Short = 4
	Const FBJOIN_MODE As Short = 5
	Const FBOJOIN_MODE As Short = 6
	Const FBUPDATE_MODE As Short = 7
	
	'/* ------- fberror code ----- */
	Const FBEBADFB As Short = 3
	Const FBEINVAL As Short = 4
	Const FBELIMIT As Short = 5
	Const FBENOENT As Short = 6
	Const FBEOS As Short = 7
	Const FBEBADFLD As Short = 8
	Const FBEPROTO As Short = 9
	Const FBENOSPACE As Short = 10
	Const FBEMALLOC As Short = 11
	Const FBESYSTEM As Short = 12
	Const FBETYPE As Short = 13
	Const FBEMATCH As Short = 14
	Const FBEBADSTRUCT As Short = 15
	Const FBEMAXNO As Short = 19
	
	
	Declare Function getfberrno Lib "TMAX4GL.DLL" () As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbget Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByRef Fieldlen As Integer) As Integer
    Declare Function fbget Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByRef Fieldlen As Integer) As Integer
    Declare Function fbget Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByRef Fieldlen As Integer) As Integer
    Declare Function fbget Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByRef Fieldlen As Integer) As Integer

	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbput Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer) As Integer
    Declare Function fbput Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer) As Integer
    Declare Function fbput Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer) As Integer
    Declare Function fbput Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbinsert Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer) As Integer
    Declare Function fbinsert Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer) As Integer
    Declare Function fbinsert Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer) As Integer
    Declare Function fbinsert Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbupdate Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer) As Integer
    Declare Function fbupdate Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer) As Integer
    Declare Function fbupdate Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer) As Integer
    Declare Function fbupdate Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer) As Integer

    Declare Function fbdelete Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
    Declare Function fbgetval Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef Fieldlen As Integer) As Integer

	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbgetnth Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer) As Integer
    Declare Function fbgetnth Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer) As Integer
    Declare Function fbgetnth Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer) As Integer
    Declare Function fbgetnth Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer) As Integer

    Declare Function fbkeyoccur Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbgetf Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByRef Fieldlen As Integer, ByRef Pos As Integer) As Integer
    Declare Function fbgetf Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByRef Fieldlen As Integer, ByRef Pos As Integer) As Integer
    Declare Function fbgetf Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByRef Fieldlen As Integer, ByRef Pos As Integer) As Integer
    Declare Function fbgetf Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByRef Fieldlen As Integer, ByRef Pos As Integer) As Integer

	Declare Function fbdelall Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer) As Integer
	Declare Function fbfldcount Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbispres Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
	Declare Function fbgetvals Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
	Declare Function fbgetvali Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
	
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbtypecvt Lib "TMAX4GL.DLL" (ByRef tolen As Integer, ByVal totype As Integer, ByRef fromval As String, ByVal fromtype As Integer, ByVal fromlen As Integer) As Integer
    Declare Function fbtypecvt Lib "TMAX4GL.DLL" (ByRef tolen As Integer, ByVal totype As Integer, ByRef fromval As Integer, ByVal fromtype As Integer, ByVal fromlen As Integer) As Integer
    Declare Function fbtypecvt Lib "TMAX4GL.DLL" (ByRef tolen As Integer, ByVal totype As Integer, ByRef fromval As Double, ByVal fromtype As Integer, ByVal fromlen As Integer) As Integer
    Declare Function fbtypecvt Lib "TMAX4GL.DLL" (ByRef tolen As Integer, ByVal totype As Integer, ByRef fromval As Byte, ByVal fromtype As Integer, ByVal fromlen As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbputt Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbputt Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbputt Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbputt Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer

    Declare Function fbgetvalt Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef Fieldlen As Integer, ByVal totype As Integer) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbgetntht Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer, ByVal fromtype As Integer) As Integer
    Declare Function fbgetntht Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer, ByVal fromtype As Integer) As Integer
    Declare Function fbgetntht Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer, ByVal fromtype As Integer) As Integer
    Declare Function fbgetntht Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer, ByVal fromtype As Integer) As Integer

	Declare Function fbget_fldkey Lib "TMAX4GL.DLL" (ByVal Fname As String) As Integer
	Declare Function fbget_fldname Lib "TMAX4GL.DLL" (ByVal fieldid As Integer) As Integer
	Declare Function fbget_fldno Lib "TMAX4GL.DLL" (ByVal fieldid As Integer) As Integer
	Declare Function fbget_fldtype Lib "TMAX4GL.DLL" (ByVal fieldid As Integer) As Integer
	Declare Function fbget_strfldtype Lib "TMAX4GL.DLL" (ByVal fieldid As Integer) As Integer
	Declare Function fbmake_fldkey Lib "TMAX4GL.DLL" (ByVal ftype As Integer, ByVal no As Integer) As Integer
	Declare Function fbnmkey_unload Lib "TMAX4GL.DLL" () As Integer
	Declare Function fbkeynm_unload Lib "TMAX4GL.DLL" () As Integer
	
	Declare Function fbisfbuf Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbcalcsize Lib "TMAX4GL.DLL" (ByVal count As Integer, ByVal datalen As Integer) As Integer
	Declare Function fbinit Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal buflen As Integer) As Integer
	Declare Function fballoc Lib "TMAX4GL.DLL" (ByVal count As Integer, ByVal buflen As Integer) As Integer
	Declare Function fbfree Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbget_fbsize Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbget_unused Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbget_used Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer) As Integer
	Declare Function fbrealloc Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal count As Integer, ByVal nlen As Integer) As Integer
	
	Declare Function fbbufop Lib "TMAX4GL.DLL" (ByVal pdFBUF As Integer, ByVal psFBUF As Integer, ByVal mode As Integer) As Integer
	Declare Function fbbufop_proj Lib "TMAX4GL.DLL" (ByVal pdFBUF As Integer, ByVal psFBUF As Integer, ByRef fieldid As Integer) As Integer
	
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbchg_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer) As Integer
    Declare Function fbchg_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer) As Integer
    Declare Function fbchg_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer) As Integer
    Declare Function fbchg_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer) As Integer

    Declare Function fbdelall_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef fieldid As Integer) As Integer
	Declare Function fbgetval_last_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef fieldocc As Integer, ByRef Fieldlen As Integer) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbget_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As String, ByRef maxlen As Integer) As Integer
    Declare Function fbget_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Integer, ByRef maxlen As Integer) As Integer
    Declare Function fbget_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Double, ByRef maxlen As Integer) As Integer
    Declare Function fbget_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef pbuffer As Byte, ByRef maxlen As Integer) As Integer

    Declare Function fbgetalloc_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer, ByRef extralen As Integer) As Integer
	'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbgetlast_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef fieldocc As Integer, ByRef pbuffer As String, ByRef maxlen As Integer) As Integer
    Declare Function fbgetlast_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef fieldocc As Integer, ByRef pbuffer As Integer, ByRef maxlen As Integer) As Integer
    Declare Function fbgetlast_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef fieldocc As Integer, ByRef pbuffer As Double, ByRef maxlen As Integer) As Integer
    Declare Function fbgetlast_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByRef fieldocc As Integer, ByRef pbuffer As Byte, ByRef maxlen As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbnext_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef fieldid As Integer, ByRef nth As Integer, ByRef pbuffer As String, ByRef Fieldlen As Integer) As Integer
    Declare Function fbnext_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef fieldid As Integer, ByRef nth As Integer, ByRef pbuffer As Integer, ByRef Fieldlen As Integer) As Integer
    Declare Function fbnext_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef fieldid As Integer, ByRef nth As Integer, ByRef pbuffer As Double, ByRef Fieldlen As Integer) As Integer
    Declare Function fbnext_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef fieldid As Integer, ByRef nth As Integer, ByRef pbuffer As Byte, ByRef Fieldlen As Integer) As Integer

    Declare Function fbgetvals_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
	Declare Function fbgetvall_tu Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbchg_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As String, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbchg_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Integer, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbchg_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Double, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbchg_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Byte, ByVal Fieldlen As Integer, ByVal ftype As Integer) As Integer

    'UPGRADE_ISSUE: �Ű� ������ 'As Any'�� ������ �� �����ϴ�. �ڼ��� ������ ms-help://MS.MSDNVS/vbcon/html/vbup1016.htm ����Ʈ�� �����Ͻʽÿ�.
    Declare Function fbget_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As String, ByRef Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbget_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Integer, ByRef Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbget_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Double, ByRef Fieldlen As Integer, ByVal ftype As Integer) As Integer
    Declare Function fbget_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByRef pbuffer As Byte, ByRef Fieldlen As Integer, ByVal ftype As Integer) As Integer

    Declare Function fbgetalloc_tut Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal nth As Integer, ByVal totype As Integer, ByRef extralen As Integer) As Integer
	Declare Function fbgetlen Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByVal fieldid As Integer, ByVal fieldocc As Integer) As Integer
	
	Declare Function fbftos Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef cstruct As Integer, ByRef stname As Integer) As Integer
	Declare Function fbstof Lib "TMAX4GL.DLL" (ByVal pFBUF As Integer, ByRef cstruct As Integer, ByVal mode As Integer, ByRef stname As Integer) As Integer
	Declare Function fbsnull Lib "TMAX4GL.DLL" (ByRef cstruct As Integer, ByRef cname As Integer, ByVal fieldocc As Integer, ByRef stname As Integer) As Integer
	Declare Function fbstinit Lib "TMAX4GL.DLL" (ByRef cstruct As Integer, ByRef stname As Integer) As Integer
	Declare Function fbstelinit Lib "TMAX4GL.DLL" (ByRef cstruct As Integer, ByRef cname As Integer, ByRef stname As Integer) As Integer
	
	Declare Function fbstrerror Lib "TMAX4GL.DLL" (ByVal err_no As Integer) As Integer
End Module