Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents cmdGetvar As System.Windows.Forms.Button
    Friend WithEvents cmdFbputvar As System.Windows.Forms.Button
    Friend WithEvents text1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents text2 As System.Windows.Forms.TextBox
    Friend WithEvents text3 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents grid1 As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents cmdFbgetvara As System.Windows.Forms.Button
    Friend WithEvents cmdFbgetvarf As System.Windows.Forms.Button
    Friend WithEvents cmdPutvar As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmdPutvar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cmdFbputvar = New System.Windows.Forms.Button()
        Me.cmdGetvar = New System.Windows.Forms.Button()
        Me.grid1 = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.cmdFbgetvarf = New System.Windows.Forms.Button()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.cmdFbgetvara = New System.Windows.Forms.Button()
        Me.text3 = New System.Windows.Forms.TextBox()
        Me.text2 = New System.Windows.Forms.TextBox()
        Me.text1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.grid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(288, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 24)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "End"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdPutvar
        '
        Me.cmdPutvar.Location = New System.Drawing.Point(416, 376)
        Me.cmdPutvar.Name = "cmdPutvar"
        Me.cmdPutvar.Size = New System.Drawing.Size(80, 32)
        Me.cmdPutvar.TabIndex = 6
        Me.cmdPutvar.Text = "PUTVAR"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(104, 48)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(128, 24)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Clear"
        '
        'cmdFbputvar
        '
        Me.cmdFbputvar.Location = New System.Drawing.Point(320, 376)
        Me.cmdFbputvar.Name = "cmdFbputvar"
        Me.cmdFbputvar.Size = New System.Drawing.Size(88, 32)
        Me.cmdFbputvar.TabIndex = 1
        Me.cmdFbputvar.Text = "FBPUTVAR"
        '
        'cmdGetvar
        '
        Me.cmdGetvar.Location = New System.Drawing.Point(128, 376)
        Me.cmdGetvar.Name = "cmdGetvar"
        Me.cmdGetvar.Size = New System.Drawing.Size(88, 32)
        Me.cmdGetvar.TabIndex = 1
        Me.cmdGetvar.Text = "GETVAR"
        '
        'grid1
        '
        Me.grid1.Location = New System.Drawing.Point(24, 80)
        Me.grid1.Name = "grid1"
        Me.grid1.OcxState = CType(resources.GetObject("grid1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.grid1.Size = New System.Drawing.Size(536, 288)
        Me.grid1.TabIndex = 4
        '
        'cmdFbgetvarf
        '
        Me.cmdFbgetvarf.Location = New System.Drawing.Point(32, 376)
        Me.cmdFbgetvarf.Name = "cmdFbgetvarf"
        Me.cmdFbgetvarf.Size = New System.Drawing.Size(88, 32)
        Me.cmdFbgetvarf.TabIndex = 1
        Me.cmdFbgetvarf.Text = "FBGETVARF"
        '
        'cmdFbgetvara
        '
        Me.cmdFbgetvara.Location = New System.Drawing.Point(224, 376)
        Me.cmdFbgetvara.Name = "cmdFbgetvara"
        Me.cmdFbgetvara.Size = New System.Drawing.Size(88, 32)
        Me.cmdFbgetvara.TabIndex = 1
        Me.cmdFbgetvara.Text = "FBGETVAR"
        '
        'text3
        '
        Me.text3.AcceptsReturn = True
        Me.text3.AutoSize = False
        Me.text3.Location = New System.Drawing.Point(368, 40)
        Me.text3.Name = "text3"
        Me.text3.Size = New System.Drawing.Size(112, 24)
        Me.text3.TabIndex = 2
        Me.text3.Text = ""
        '
        'text2
        '
        Me.text2.AcceptsReturn = True
        Me.text2.AutoSize = False
        Me.text2.Location = New System.Drawing.Point(368, 8)
        Me.text2.Name = "text2"
        Me.text2.Size = New System.Drawing.Size(112, 24)
        Me.text2.TabIndex = 2
        Me.text2.Text = ""
        '
        'text1
        '
        Me.text1.AcceptsReturn = True
        Me.text1.AutoSize = False
        Me.text1.Location = New System.Drawing.Point(104, 16)
        Me.text1.Name = "text1"
        Me.text1.Size = New System.Drawing.Size(112, 24)
        Me.text1.TabIndex = 2
        Me.text1.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 24)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Count"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(288, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 24)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Start"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
        Me.ClientSize = New System.Drawing.Size(568, 453)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdPutvar, Me.Button1, Me.grid1, Me.text3, Me.Label3, Me.Label2, Me.text2, Me.Label1, Me.text1, Me.cmdFbputvar, Me.cmdFbgetvara, Me.cmdGetvar, Me.cmdFbgetvarf})
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.grid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private initcheck As Boolean

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tmaxinit()
    End Sub

    Private Sub Form1_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed

        Call tmaxexit()

    End Sub

    Private Sub tmaxinit()
        Dim lsndbuf As Integer
        Dim ret As Short
        Dim sndbuf As Integer
        Dim env As String

        If tmaxreadenv("c:\temp\tmax.env", "TMAX") = -1 Then
            MsgBox(("read env file error") & "," & gettperrno())
            Exit Sub
        End If

        lsndbuf = tpalloc("TPSTART", "", 0)
        If lsndbuf = 0 Then
            MsgBox("send buffer allocation error" & gettperrno())
            Exit Sub
        End If

        If PUTCAR(lsndbuf, "hslee", 18) < 0 Then
            MsgBox("putcar error")
        End If

        If PUTCAR(lsndbuf + 18, "tmax", 18) < 0 Then 'cltname
            MsgBox("putcar error")
        End If

        ret = tpstart(lsndbuf)
        If ret = -1 Then
            MsgBox(("tp start error") & "," & gettperrno())
            initcheck = False
            End
        End If

        initcheck = True

    End Sub

    Private Function tmaxexit() As Boolean

        If tpend() = -1 Then
            MsgBox(("tp end error") & "," & gettperrno())
            tmaxexit = False
            Exit Function
        End If

        tmaxexit = True

    End Function

    Private Sub cmdFbgetvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFbgetvarf.Click
        Dim lsndbuf As Long
        Dim lrcvbuf As Long
        Dim lrbuflen As Long
        Dim lret As Long
        Dim Text(1000, 9) As String
        Dim Int1, i, j, ret As Integer
        Dim pos1, pos2, pos3, pos4, pos5, pos6, pos7, pos8, pos9 As Integer

        If initcheck = False Then
            MsgBox("TMAX������ ������ �����Դϴ�. ������ �� �����ϴ�")
            Exit Sub
        End If

        lsndbuf = tpalloc("FIELD", "", 1024)
        lrcvbuf = tpalloc("FIELD", "", 1024)

        If lsndbuf = 0 Or lrcvbuf = 0 Then
            MsgBox("buffer allocation error" & gettperrno())
            Exit Sub
        End If


        If PUTVAR(lsndbuf, "INPUT", 0, text1.Text) = -1 Then
            MsgBox("putvar error")
            Goto memoryfree
        End If

        If tpcall("FEBISSVC", lsndbuf, 0, lrcvbuf, lrbuflen, 0) = -1 Then
            MsgBox("tpcall error " & gettperrno())
            Goto memoryfree
        End If

        Int1 = Val(text1.Text)


        pos1 = pos2 = pos3 = pos4 = pos5 = pos6 = pos7 = pos8 = pos9 = 0
        text2.Text = TimeString()

        For i = 1 To Int1
            ret = FBGETVARF(lrcvbuf, "FDL_1", Text(i, 1), pos1)
            ret = FBGETVARF(lrcvbuf, "FDL_2", Text(i, 2), pos2)
            ret = FBGETVARF(lrcvbuf, "FDL_3", Text(i, 3), pos3)
            ret = FBGETVARF(lrcvbuf, "FDL_4", Text(i, 4), pos4)
            ret = FBGETVARF(lrcvbuf, "FDL_5", Text(i, 5), pos5)
            ret = FBGETVARF(lrcvbuf, "FDL_6", Text(i, 6), pos6)
            ret = FBGETVARF(lrcvbuf, "FDL_7", Text(i, 7), pos7)
            ret = FBGETVARF(lrcvbuf, "FDL_8", Text(i, 8), pos8)
            ret = FBGETVARF(lrcvbuf, "FDL_9", Text(i, 9), pos9)
        Next


        text3.Text = TimeString()

        grid1.Redraw = False
        For i = 1 To Int1
            For j = 1 To 9
                grid1.Col = j
                grid1.Row = i
                grid1.Text = Text(i, j)
            Next
        Next
        grid1.Redraw = True

memoryfree:
        tpfree(lsndbuf)
        tpfree(lrcvbuf)
    End Sub

    Private Sub cmdGetvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGetvar.Click
        Dim lsndbuf As Long
        Dim lrcvbuf As Long
        Dim lrbuflen As Long
        Dim lret As Long
        Dim code As String
        Dim sql As String
        Dim Text(1000, 9) As String
        Dim Int1, i, j, ret As Integer

        If initcheck = False Then
            MsgBox("TMAX������ ������ �����Դϴ�. ������ �� �����ϴ�")
            Exit Sub
        End If

        lsndbuf = tpalloc("FIELD", "", 1024)
        lrcvbuf = tpalloc("FIELD", "", 1024)

        If lsndbuf = 0 Or lrcvbuf = 0 Then
            MsgBox("buffer allocation error" & gettperrno())
            Exit Sub
        End If

        code = "S01"

        If PUTVAR(lsndbuf, "STR100", 0, code) = -1 Then
            MsgBox("putvar error")
            Goto memoryfree
        End If

        sql = "SELECT sil_no, pjuso, sil_no, pjuso FROM sa_imaechul WHERE gr_cd between '000001' and '000100'"
        If PUTVAR(lsndbuf, "STR001", 0, sql) = -1 Then
            MsgBox("putvar error")
            Goto memoryfree
        End If

        If tpcall("CSAI290_01", lsndbuf, 0, lrcvbuf, lrbuflen, 0) = -1 Then
            MsgBox("tpcall error " & gettperrno())
            Goto memoryfree
        End If

        'Int1 = Val(text1.Text)
        Int1 = fbkeyoccur(lrcvbuf, fbget_fldkey("STR101"))
        text2.Text = TimeString()

        grid1.Clear()

        For i = 1 To Int1
            ret = GETVAR(lrcvbuf, "STR101", i - 1, Text(i, 1))
            ret = GETVAR(lrcvbuf, "STR102", i - 1, Text(i, 2))
            ret = GETVAR(lrcvbuf, "STR103", i - 1, Text(i, 3))
            ret = GETVAR(lrcvbuf, "STR104", i - 1, Text(i, 4))
            'ret = GETVAR(lrcvbuf, "FDL_5", i, Text(i, 5))
            'ret = GETVAR(lrcvbuf, "FDL_6", i, Text(i, 6))
            'ret = GETVAR(lrcvbuf, "FDL_7", i, Text(i, 7))
            'ret = GETVAR(lrcvbuf, "FDL_8", i, Text(i, 8))
            'ret = GETVAR(lrcvbuf, "FDL_9", i, Text(i, 9))

        Next

        text3.Text = TimeString()

        grid1.Redraw = False
        For i = 1 To Int1
            For j = 1 To 4
                grid1.Col = j
                grid1.Row = i
                grid1.Text = Text(i, j)
            Next
        Next
        grid1.Redraw = True

memoryfree:
        tpfree(lsndbuf)
        tpfree(lrcvbuf)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        grid1.Clear()
        text2.Text = ""
        text3.Text = ""
    End Sub

    Private Sub cmdFbgetvarf_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFbgetvara.Click
        Dim lsndbuf As Long
        Dim lrcvbuf As Long
        Dim lrbuflen As Long
        Dim lret As Long
        Dim code As String
        Dim sql As String
        Dim Text(1000, 9) As String
        Dim Int1, i, j, ret As Integer

        If initcheck = False Then
            MsgBox("TMAX������ ������ �����Դϴ�. ������ �� �����ϴ�")
            Exit Sub
        End If

        lsndbuf = tpalloc("FIELD", "", 1024)
        lrcvbuf = tpalloc("FIELD", "", 1024)

        If lsndbuf = 0 Or lrcvbuf = 0 Then
            MsgBox("buffer allocation error" & gettperrno())
            Exit Sub
        End If

        code = "S01"

        If PUTVAR(lsndbuf, "STR100", 0, code) = -1 Then
            MsgBox("putvar error")
            Goto memoryfree
        End If

        sql = "SELECT sil_no, pjuso, sil_no, pjuso FROM sa_imaechul WHERE gr_cd between '000001' and '000100'"
        If PUTVAR(lsndbuf, "STR001", 0, sql) = -1 Then
            MsgBox("putvar error")
            Goto memoryfree
        End If

        If tpcall("CSAI290_01", lsndbuf, 0, lrcvbuf, lrbuflen, 0) = -1 Then
            MsgBox("tpcall error " & gettperrno())
            Goto memoryfree
        End If

        'Int1 = Val(text1.Text)
        Int1 = fbkeyoccur(lrcvbuf, fbget_fldkey("STR101"))
        text2.Text = TimeString()

        grid1.Clear()

        For i = 1 To Int1
            ret = FBGETVAR(lrcvbuf, "STR101", Text(i, 1))
            ret = FBGETVAR(lrcvbuf, "STR102", Text(i, 2))
            ret = FBGETVAR(lrcvbuf, "STR103", Text(i, 3))
            ret = FBGETVAR(lrcvbuf, "STR104", Text(i, 4))
            'ret = FBGETVAR(lrcvbuf, "FDL_5", Text(i, 5))
            'ret = FBGETVAR(lrcvbuf, "FDL_6", Text(i, 6))
            'ret = FBGETVAR(lrcvbuf, "FDL_7", Text(i, 7))
            'ret = FBGETVAR(lrcvbuf, "FDL_8", Text(i, 8))
            'ret = FBGETVAR(lrcvbuf, "FDL_9", Text(i, 9))
        Next

        'For i = 1 To Int1
        '    ret = FBGETLONG(lrcvbuf, "FDL_L1", Text(i, 1))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L2", Text(i, 2))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L3", Text(i, 3))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L4", Text(i, 4))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L5", Text(i, 5))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L6", Text(i, 6))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L7", Text(i, 7))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L8", Text(i, 8))
        '    ret = FBGETLONG(lrcvbuf, "FDL_L9", Text(i, 9))
        'Next
        text3.Text = TimeString()

        grid1.Redraw = False
        For i = 1 To Int1
            For j = 1 To 4
                grid1.Col = j
                grid1.Row = i
                grid1.Text = Text(i, j)
            Next
        Next
        grid1.Redraw = True

memoryfree:
        tpfree(lsndbuf)
        tpfree(lrcvbuf)
    End Sub

    Private Sub cmdPutvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPutvar.Click
        Dim lsndbuf As Long
        Dim Text As String
        Dim Int1, i, ret As Integer

        If initcheck = False Then
            MsgBox("TMAX������ ������ �����Դϴ�. ������ �� �����ϴ�")
            Exit Sub
        End If

        lsndbuf = tpalloc("FIELD", "", 1024)

        If lsndbuf = 0 Then
            MsgBox("buffer allocation error" & gettperrno())
            Goto memoryfree
        End If

        Int1 = Val(text1.Text)
        text2.Text = TimeString()
        Text = "123455678901234567890"
        For i = 1 To Int1
            ret = PUTVAR(lsndbuf, "FDL_1", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_2", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_3", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_4", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_5", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_6", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_7", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_8", 0, Text)
            ret = PUTVAR(lsndbuf, "FDL_9", 0, Text)
        Next

        text3.Text = TimeString()

memoryfree:
        tpfree(lsndbuf)
    End Sub

    Private Sub cmdFbputvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFbputvar.Click
        Dim lsndbuf, lrcvbuf As Long
        Dim Text As String
        Dim Int1, i, ret, lrbuflen As Integer

        If initcheck = False Then
            MsgBox("TMAX������ ������ �����Դϴ�. ������ �� �����ϴ�")
            Exit Sub
        End If

        lsndbuf = tpalloc("FIELD", "", 300000)
        lrcvbuf = tpalloc("FIELD", "", 1024)

        If lsndbuf = 0 Or lrcvbuf = 0 Then
            MsgBox("buffer allocation error" & gettperrno())
            Goto memoryfree
        End If

        Int1 = Val(text1.Text)
        text2.Text = TimeString()
        Text = "123455678901234567890"
        For i = 1 To Int1
            ret = FBPUTVAR(lsndbuf, "FDL_1", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_2", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_3", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_4", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_5", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_6", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_7", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_8", Text)
            ret = FBPUTVAR(lsndbuf, "FDL_9", Text)
        Next

        text3.Text = TimeString()

        If tpcall("FEBISSVC2", lsndbuf, 0, lrcvbuf, lrbuflen, 0) = -1 Then
            MsgBox("tpcall error " & gettperrno())
            Goto memoryfree
        End If
memoryfree:
        tpfree(lsndbuf)
    End Sub

    Private Sub grid1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grid1.Enter

    End Sub
End Class
