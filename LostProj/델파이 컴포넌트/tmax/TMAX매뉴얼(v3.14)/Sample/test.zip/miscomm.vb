Option Strict Off
Option Explicit On 

Imports System
Imports System.Runtime.InteropServices
Imports System.Text

Module comm

    '**************************************************************************
    '* Dot Net �� �Լ���
    '**************************************************************************
    Declare Function PUTINT Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Integer) As Integer
    Declare Function PUTLONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Integer) As Integer
    Declare Function PUTDOUBLE Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Double) As Integer
    Declare Function PUTVAR Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef sData As String) As Integer
    Declare Function PUTCAR Lib "TMAXDOT.DLL" (ByVal ptr As Integer, ByRef str As String, ByRef lng As Integer) As Integer
    Declare Function GETCAR Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef str As String, ByVal i As Integer) As Integer
    Declare Function GETSTR Lib "TMAXDOT.DLL" (ByVal Fdlptr As Integer, _
        ByRef Texts As String) As Integer
    Declare Function GETINT Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Integer) As Integer
    Declare Function GETLONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Integer) As Integer
    Declare Function GETDOUBLE Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef iData As Double) As Integer
    Declare Function GETVAR Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        <MarshalAs(UnmanagedType.LPStr)> ByRef field As String, ByRef idx As Integer, _
        <MarshalAs(UnmanagedType.LPStr)> ByRef sData As String) As Integer

    Declare Function GETVAR_LONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef idx As Integer, ByRef sData As String) As Integer
    Declare Function GETSTR_LONG Lib "TMAXDOT.DLL" (ByVal Fdlptr As Integer, _
        ByRef Texts As String) As Integer
    Declare Function GETCAR_LONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef str As String, ByVal i As Integer) As Integer
    
    Declare Function FBPUTVAR Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
         ByRef field As String, ByRef sData As String) As Integer
    Declare Function FBPUTINT Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String,  ByRef iData As Integer) As Integer
    Declare Function FBPUTLONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String,  ByRef iData As Integer) As Integer
    Declare Function FBPUTDOUBLE Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String,  ByRef iData As Double) As Integer
            
    Declare Function FBGETVAR Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
                <MarshalAs(UnmanagedType.LPStr)> ByRef field As String, _
                <MarshalAs(UnmanagedType.LPStr)> ByRef sData As String) As Integer
    Declare Function FBGETINT Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Integer) As Integer
    Declare Function FBGETLONG Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Integer) As Integer
    Declare Function FBGETDOUBLE Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Double) As Integer
        
    Declare Function FBGETVARF Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
            <MarshalAs(UnmanagedType.LPStr)> ByRef field As String, _
            <MarshalAs(UnmanagedType.LPStr)> ByRef sData As String, ByRef posNo As Integer) As Integer
    Declare Function FBGETINTF Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Integer, ByRef posNo As Integer) As Integer
    Declare Function FBGETLONGF Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Integer, ByRef posNo As Integer) As Integer
    Declare Function FBGETDOUBLEF Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        ByRef field As String, ByRef iData As Double, ByRef posNo As Integer) As Integer

    Declare Function GETCAR_BA Lib "TMAXDOT.DLL" (ByVal pFBFR As Integer, _
        <MarshalAs(UnmanagedType.LPStr)> ByRef field As String, ByRef idx As Integer, _
        <MarshalAs(UnmanagedType.LPStr)> ByRef sData As Byte, ByRef sLen As Integer) As Integer
    '**************************************************************************
    '* Dot Net �� �Լ���(�������)
    '**************************************************************************

    '***************************************************************
    '   Function: Display Error Msg of ATMI Function For FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Service : ATMI API Function
    '***************************************************************
    Function FdlErrorMsg(ByRef service As String) As Short

        Dim lret As Integer
        Dim ret As Integer
        Dim ErrMsg As String
        Dim Errmsgs As String
        Dim fdl_err_no As Integer
        Dim errptr As Integer
        Dim tpurcode As Integer
        Dim msgString As String

        ' Error Msg of Client Program
        fdl_err_no = getfberrno()
        errptr = fbstrerror(fdl_err_no)

        ErrMsg = Space(100)

        ret = lstrcpy(ErrMsg, errptr)

        msgString = service & " Failed." & Chr(13)
        If Len(Trim(ErrMsg)) > 0 Then
            msgString = msgString & Left(ErrMsg, Len(Trim(ErrMsg)) - 1) & Chr(13)
        End If

        MsgBox(msgString)

    End Function
    '***************************************************************
    '   Function: Put The Integer Data Into FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   iData   : INTEGER DATA
    '***************************************************************
    Function _PUTINT(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef iData As Integer) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbchg_tu(Fdlptr, fbget_fldkey(Field), idx, iData, 0)

        _PUTINT = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbchg_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Put The Long Data Into FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   iData   : LONG DATA
    '***************************************************************
    Function _PUTLONG(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef lData As Integer) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbchg_tu(Fdlptr, fbget_fldkey(Field), idx, lData, 0)

        _PUTLONG = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbchg_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Put The Double Data Into FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   iData   : DOUBLE DATA
    '***************************************************************
    Function _PUTDOUBLE(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef dData As Double) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbchg_tu(Fdlptr, fbget_fldkey(Field), idx, dData, 0)

        _PUTDOUBLE = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbchg_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Put The String Data Into FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   text    : STRING DATA
    '***************************************************************
    Function _PUTVAR(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef text As String) As Short

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbchg_tu(Fdlptr, fbget_fldkey(Field), idx, text, 0)

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbchg_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Put The String or Image Data Into String or CARRAY Buffer
    '   Fdlptr  : STRING OR CARRAY BUFFER POINTER
    '   text    : STRING DATA
    '   datalen : DATA LENGTH
    '***************************************************************
    Function _PUTCAR(ByVal Fdlptr As Integer, ByRef text As String, ByRef datalen As Integer) As Object

        Dim ret As Integer
        Dim err_ret As Short

        ret = lstrcpyn(Fdlptr, text, datalen)

        If ret = -1 Then
            err_ret = FdlErrorMsg("lstrcpyn")
        End If

    End Function
    '***************************************************************
    '   Function: Put The Image Data Into FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   text    : STRING DATA
    '***************************************************************
    Function _PUTCAR_BA(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef ByteArray() As Byte, ByRef datalen As Integer) As Short

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short


        ret = fbchg_tu(Fdlptr, fbget_fldkey(Field), idx, ByteArray(0), datalen)
        '   ret = fbchg_tu(ByVal Fdlptr&, ByVal fbget_fldkey(Field), idx, ByVal snddata$, ByVal datalen)

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbchg_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Get The Integer Data
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   iData    : LOCAL VARIABLE
    '***************************************************************
    Function _GETINT(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef iData As Integer) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbget_tu(Fdlptr, fbget_fldkey(Field), idx, iData, 0)

        _GETINT = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbget_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Get The Long Data
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   lData    : LOCAL VARIABLE
    '***************************************************************
    Function _GETLONG(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef lData As Integer) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbget_tu(Fdlptr, fbget_fldkey(Field), idx, lData, 0)

        _GETLONG = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbget_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Get The Double Data
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   dData    : LOCAL VARIABLE
    '***************************************************************
    Function _GETDOUBLE(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef dData As Double) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short

        ret = fbget_tu(Fdlptr, fbget_fldkey(Field), idx, dData, 0)

        _GETDOUBLE = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbget_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Get The String Data From FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   text    : LOCAL VARIABLE
    '             No Text property of Control
    '***************************************************************
    Function _GETVAR(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef text As String) As Object

        '    Dim data As String * 512
        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short
        Dim location As Integer
        Dim aaa As Integer

        text = New String(Chr(0), 1024)

        aaa = fbget_fldkey(Field)
        ret = fbget_tu(Fdlptr, fbget_fldkey(Field), idx, text, 0)

        location = InStr(text, Chr(0))
        If (location > 0) Then
            text = Trim(Left(text, location - 1))
        End If

        _GETVAR = ret

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbget_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Get The String Data From String Buffer
    '   Fdlptr  : STRING BUFFER POINTER
    '   text    : LOCAL VARIABLE
    '             No Text property of Control
    '***************************************************************
    Function _GETSTR(ByVal Fdlptr As Integer, ByRef text As String) As Object

        '    Dim data As String * 512
        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short
        Dim location As Integer

        text = New String(Chr(0), 1024)

        ret = vb_getstr(Fdlptr, text)

        location = InStr(text, Chr(0))
        If (location > 0) Then
            text = Trim(Left(text, location - 1))
        End If

        If ret = -1 Then
            err_ret = FdlErrorMsg("vb_getstr")
        End If

    End Function
    '***************************************************************
    '   Function: Get The Carray Data and DataLen From CARRAY Buffer
    '   Fdlptr  : STRING BUFFER POINTER
    '   text    : LOCAL VARIABLE
    '             No Text property of Control
    '   datalen : LOCAL VARIABLE FOR DATA LENGTH
    '***************************************************************
    Function _GETCAR(ByVal Fdlptr As Integer, ByRef text As String, ByRef datalen As Integer) As Object

        Dim ret As Integer
        Dim err_ret As Integer

        text = New String(Chr(0), 1024)

        ret = vb_getcar(Fdlptr, text, datalen)

        text = Trim(Left(text, datalen))

        If ret = -1 Then
            err_ret = FdlErrorMsg("vb_getcar")
        End If

    End Function
    '***************************************************************
    '   Function: Get The Image Data From FDL Buffer
    '   Fdlptr  : FDL BUFFER POINTER
    '   Field   : FIELD NAME
    '   idx     : OCCURRENCE OF DATA
    '   text    : LOCAL VARIABLE
    '             No Text property of Control
    '***************************************************************
    Function _GETCAR_BA(ByVal Fdlptr As Integer, ByRef Field As String, ByRef idx As Integer, ByRef ByteArray() As Byte, ByRef datalen As Integer) As Object

        Dim ret As Integer
        Dim lret As Integer
        Dim tp_err_no As Short
        Dim err_ret As Short
        Dim location As Integer

        ret = fbget_tu(Fdlptr, fbget_fldkey(Field), idx, ByteArray(0), datalen)

        If ret = -1 Then
            err_ret = FdlErrorMsg("fbget_tu")
        End If

    End Function
    '***************************************************************
    '   Function: Display StrErr plus tperrno msg
    '***************************************************************
    Sub TmaxError(ByRef StrErr As String)
        Dim tperrno As Short
        Dim tpurcode As Short
        Dim sptr As Integer
        Dim tmaxstr As String
        Dim ret As Integer
        Dim MSG As String

        tperrno = gettperrno()
        tpurcode = gettpurcode()
        sptr = tpstrerror(tperrno)
        tmaxstr = New String(Chr(0), 100)
        ret = lstrcpy(tmaxstr, sptr)
        MSG = StrErr & ": " & tmaxstr
        MsgBox(MSG)
    End Sub
    '***************************************************************
    '   Function: Making the start structure
    '***************************************************************
    Function FilltpstartBuf(ByRef sndbufp As Integer, ByRef startinfop As tpstart_t) As Object
        Static ptr As Integer
        Dim ret As Integer
        Dim slen As Integer
        Dim X As String
        Const datalen As Short = 18


        ptr = sndbufp
        ret = lstrcpyn(ptr, startinfop.usrname, datalen)

        ptr = ptr + datalen
        ret = lstrcpyn(ptr, startinfop.cltname, datalen)

        ptr = ptr + datalen
        ret = lstrcpyn(ptr, startinfop.dompwd, datalen)

        ptr = ptr + datalen
        ret = lstrcpyn(ptr, startinfop.usrpwd, datalen)

        ptr = ptr + datalen
        X = Chr(startinfop.flags) & Chr(0) & Chr(0) & Chr(0)
        slen = 4
        ret = lstrcpyn(ptr, X, slen)

    End Function
End Module