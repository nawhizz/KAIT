Vclskin patch cxScrollbar.pas, cxLookAndFeelPainters.pas

cxScrollbar.pas is patch for skin scrollbar in QuantumGrid,
cxLookAndFeelPainters.pas patch for FilterButton in column header

Install:
just copy them in your application folder, it will only effect your application, not DevExpress Component.